#!/bin/bash

# marked for documentation -> Mentions default variables. List some more useful default variables.
var="$(hostname)"
echo "Dieses Skript läuft auf $var"
