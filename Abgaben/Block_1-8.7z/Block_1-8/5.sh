#!/bin/bash
echo "Mensch Bär Schwein Hund Katze Schaf" | xargs -n1
