#!/bin/bash
var="Shell Scripting is Fun!"
echo $var
