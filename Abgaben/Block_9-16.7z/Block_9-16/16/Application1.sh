#!/bin/bash

echo -e "This is Application1 \n---------------------------------"
while true; do
  echo "Hello from Application1"
  sleep 1.5
done
wait
