#!/bin/bash


str="first second third"
arr1=($str)
echo ${arr1[1]}
