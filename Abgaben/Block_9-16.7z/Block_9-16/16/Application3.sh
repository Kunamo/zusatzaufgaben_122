#!/bin/bash
echo -e "This is Application3 \n---------------------------------"
while true; do
  echo "Hello from Application2"
  sleep 1.5
done
