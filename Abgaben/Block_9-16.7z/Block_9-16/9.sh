#!/bin/bash
#marked for "$?"

echo "This script exits with the exit-status $?"
